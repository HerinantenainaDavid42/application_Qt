#include "fenetre_liste.h"
#include <QApplication>
#include <QMainWindow>
#include <QWidget>
#include <QVBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QObject>

fenetre_liste::fenetre_liste()
{
    fenetre ->resize(150,150);
        fenetre->setWindowTitle("L'identifiant que vous recherchrez");
        fenetre->setStyleSheet("background : white;");
        // Créer un layout pour organiser les éléments de manière horizontale
        QVBoxLayout *layout = new QVBoxLayout(fenetre);
        // Créer un label et un pixmap
        QLabel *label = new QLabel("RAKOTONAMBOARINA");
        QLabel *label2 = new QLabel("Saikatsivita");
        QLabel *label3 = new QLabel("L 5");
        QPushButton *b=new QPushButton("voir détails");
        b->setStyleSheet("background:grey;border:2px solid black;border-radius:10%;");
        /*************************************************************/
        QPixmap pixmap("/home/david/Images/&&&&&&.jpeg");
        QLabel *imageLabel = new QLabel;
        imageLabel->setPixmap(pixmap);
        // Ajouter les widgets au layout
        layout->addWidget(imageLabel);
        layout->addWidget(label);
        layout->addWidget(label2);
        layout->addWidget(label3);
        layout->addWidget(b);
        layout->setAlignment(Qt::AlignTop | Qt::AlignCenter);
        // Afficher la fenêtre
        fenetre->show();
}
void clickbouton(){
    QWidget *fenetre=new QWidget();
    fenetre ->resize(150,150);
        fenetre->setWindowTitle("L'identifiant que vous recherchrez");
        // Créer un layout pour organiser les éléments de manière horizontale
        QVBoxLayout *layout = new QVBoxLayout(fenetre);
        // Créer un label et un pixmap
        QLabel *label = new QLabel("RAKOTONAMBOARINA");
        QLabel *label2 = new QLabel("Saikatsivita");
        QLabel *label3 = new QLabel("14 février 2004");
        QLabel *label4 = new QLabel("Ambohimadizina");
        QLabel *label5 = new QLabel("M 1");
        QLabel *label6 = new QLabel("e9:06:d4:06:48 ");
        QLabel *label7 = new QLabel("PAN58319");
        QLabel *label8 = new QLabel("192.128.1.23");
        QPixmap pixmap("/home/david/Images/&&&&&&&&&&&&&&&&&&&&&.jpeg");
        QLabel *imageLabel = new QLabel;
        imageLabel->setPixmap(pixmap);
        // Ajouter les widgets au layout
        layout->addWidget(imageLabel);
        layout->addWidget(label);
        layout->addWidget(label2);
        layout->addWidget(label3);
        layout->addWidget(label4);
        layout->addWidget(label5);
        layout->addWidget(label6);
        layout->addWidget(label7);
        layout->addWidget(label8);
}

