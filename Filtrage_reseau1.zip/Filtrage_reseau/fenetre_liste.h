#ifndef FENETRE_LISTE_H
#define FENETRE_LISTE_H
#include <QFrame>


class fenetre_liste
{
public:
    fenetre_liste();
    QFrame *fenetre=new QFrame();
};

#endif // FENETRE_LISTE_H
