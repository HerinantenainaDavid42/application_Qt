#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <cstdlib>
#include <QApplication>
#include <QMainWindow>
#include <QWidget>
#include <QVBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QObject>
#include <fstream>
#include <QFile>
#include <QTextEdit>
#include <cstring>
#include <stdio.h>
#include <QtWidgets>
#include <QtCore>
#include <QObject>
#include <QTextStream>

using namespace std;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

///Editer sites et MACS
void MainWindow::on_pushButton_clicked()
{
    QFrame *fenetre=new QFrame();
    fenetre ->resize(200,200);
        fenetre->setWindowTitle("Liste des règles bloqués");
        fenetre->setStyleSheet("background :rgba(20,20,20,20);");
        // Créer un layout pour organiser les éléments de manière horizontale
        QVBoxLayout *layout = new QVBoxLayout(fenetre);
        QPushButton *b1=new QPushButton("ACCEPT");
        QString str=ui->Changer->text();
        //QObject::connect(b1,&QPushButton::clicked,this,MainWindow::accepter(str));
        QPushButton *b2=new QPushButton("DROP");
        QPushButton *b3=new QPushButton("REJECT");
        b1->setStyleSheet("background:blue;");
        b2->setStyleSheet("background:blue;");
        b3->setStyleSheet("background:blue;");
        layout->addWidget(b1);
        layout->addWidget(b2);
        layout->addWidget(b3);
        fenetre->show();
}

///Listes
void MainWindow::on_pushButton_2_clicked()
{
    QFrame *fenetre=new QFrame();
    fenetre ->resize(500,500);
        fenetre->setWindowTitle("Liste des règles bloqués");
        fenetre->setStyleSheet("background :rgba(20,20,20,20) ;");
        // Créer un layout pour organiser les éléments de manière horizontale
        QVBoxLayout *layout = new QVBoxLayout(fenetre);
        QHBoxLayout *layouth=new QHBoxLayout();
        QLabel *label=new QLabel("type");
        QLabel *label2=new QLabel("Nom");
        QLabel *label3=new QLabel("Police");
        QPushButton *bouton=new QPushButton("Débloquer");
        label->setStyleSheet("background:white;");
        label2->setStyleSheet("background:white;");
        label3->setStyleSheet("background:white;");
        bouton->setStyleSheet("background:blue;");
        layouth->addWidget(label);
        layouth->addWidget(label2);
        layouth->addWidget(label3);
        layouth->addWidget(bouton);
        layout->addLayout(layouth, Qt::AlignTop);
        // Créer un label et un pixmap
        fenetre->show();
}

///Historiques
void MainWindow::on_pushButton_3_clicked()
{
    QFrame *fenetre=new QFrame();
    QTextEdit *textEdit = new QTextEdit;
    textEdit->setStyleSheet("color:white;");

    fenetre ->resize(500,500);
        fenetre->setWindowTitle("Liste des règles bloqués");
        fenetre->setStyleSheet("background : rgba(20,20,20,20);");
        // Créer un layout pour organiser les éléments de manière horizontale
        QVBoxLayout *layout = new QVBoxLayout(fenetre);
        system("iptables -L > liste.txt");
        QFile file("liste.txt");
        if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
          QString text=file.readAll();
          textEdit->setText(text);
        }
        // Ajouter le QTextEdit au QFrame
        layout->addWidget(textEdit);
        fenetre->setLayout(layout);

        fenetre->show();
}

///Editer protocoles
void MainWindow::on_pushButton_4_clicked()
{
    QFrame *fenetre=new QFrame();
    fenetre ->resize(200,200);
        fenetre->setWindowTitle("Liste des règles bloqués");
        fenetre->setStyleSheet("background :rgba(20,20,20,20);");
        // Créer un layout pour organiser les éléments de manière horizontale
        QVBoxLayout *layout = new QVBoxLayout(fenetre);
        QPushButton *b1=new QPushButton("ACCEPT");
        ///connect(b1,&QPushButton::clicked,this,MainWindow::accepter(ui->Changer->text()));
        QPushButton *b2=new QPushButton("DROP");
        QPushButton *b3=new QPushButton("REJECT");
        b1->setStyleSheet("background:blue;");
        b2->setStyleSheet("background:blue;");
        b3->setStyleSheet("background:blue;");
        layout->addWidget(b1);
        layout->addWidget(b2);
        layout->addWidget(b3);
        fenetre->show();
}

///INPUT
void MainWindow::on_comboBox_2_activated(const QString &arg1)
{
    if(arg1=="ACCEPT"){
        system("iptables -P INPUT ACCEPT");
    }
    else if(arg1=="DROP"){
        system("iptables -P INPUT DROP");
    }
    else{
        system("iptables -P INPUT REJECT");
    }
}

///OUTPUT
void MainWindow::on_comboBox_3_activated(const QString &arg1)
{
    if(arg1=="ACCEPT"){
        system("iptables -P OUTPUT ACCEPT");
    }
    else if(arg1=="DROP"){
        system("iptables -P OUTPUT DROP");
    }
    else{
        system("iptables -P OUTPUT REJECT");
    }
}

///FORWARD
void MainWindow::on_comboBox_4_activated(const QString &arg1)
{
    if(arg1=="ACCEPT"){
        system("iptables -P FORWARD ACCEPT");
    }
    else if(arg1=="DROP"){
        system("iptables -P FORWARD DROP");
    }
    else{
        system("iptables -P FORWARD REJECT");
    }
}

///Réinitialisation
void MainWindow::on_pushButton_5_clicked()
{
    system("iptables -F");
    system("iptables -P OUTPUT ACCEPT");
    system("iptables -P INPUT ACCEPT");
    system("iptables -P FORWARD ACCEPT");
    ///ui->comboBox_2->
}

///Type
void MainWindow::on_comboBox_5_activated(const QString &arg1)
{
    if(arg1=="site"){
        ui->Changer->setPlaceholderText("www.domaine.exemple");
    }
    if(arg1=="MAC"){
        ui->Changer->setPlaceholderText("Adresse MAC");
    }
    if(arg1=="IP"){
        ui->Changer->setPlaceholderText("255.255.255.255");
    }
}

///Ajouter protocole
void MainWindow::on_comboBox_activated(const QString &arg1)
{
    if(arg1=="Ajouter"){
        QFrame *fenetre=new QFrame();
        fenetre ->resize(300,200);
        fenetre->setWindowTitle("Ajout de protocole");
        fenetre->setStyleSheet("background :rgba(20,20,20,20);");
        // Créer un layout pour organiser les éléments de manière horizontale
        QVBoxLayout *layout = new QVBoxLayout(fenetre);
        QLineEdit *edit=new QLineEdit();
        QPushButton * add=new QPushButton("Ajouter");
        add->setStyleSheet("background:blue;font-size:25px;");
        edit->setStyleSheet("background:white;font-size:25px;");
        edit->setPlaceholderText("protocole(port)");
        layout->addWidget(edit);
        layout->addWidget(add);

        fenetre->show();
    }
}

void MainWindow::accepter(QString saisie){
    string saisietostring =saisie.toStdString();
   const char *saisietochar=(char*)malloc(50);
    saisietochar= saisietostring.c_str();
    char* cmd=(char*)malloc(100);
     strcpy(cmd,"iptables -A INPUT -s ");
     strcat(cmd,saisietochar);
     strcat(cmd,"-j ACCEPT");
     system(cmd);
}
